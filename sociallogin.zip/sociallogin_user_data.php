<?php
if ( !defined( '_PS_VERSION_' ) ){
	exit;
}

class LrUser{
	function __construct(){
		include_once("LoginRadius.php");
		$secret = Configuration::get('API_SECRET');
		$lr_obj=new LoginRadius();
		$userprofile=$lr_obj->loginradius_get_data($secret);
		if(!empty($userprofile->BirthDate) and strlen($userprofile->BirthDate)>9){
			$birthDate = $userprofile->BirthDate;
			$birthDate = $birthDate['6'].$birthDate['7'].$birthDate['8'].$birthDate['9']."-".$birthDate['0'].$birthDate['1']."-".$birthDate['3'].$birthDate['4'];
			$userprofile->BirthDate = $birthDate;
		}
		if (!empty($userprofile->FirstName) && !empty( $userprofile->LastName )) {
			$userprofile->username= $userprofile->FirstName. ' ' . $userprofile->LastName ;
		}
		elseif (!empty($userprofile->FullName)) {
			$userprofile->username= $userprofile->FullName;
		}
		elseif (!empty($userprofile->ProfileName)) {
			$userprofile->username = $userprofile->ProfileName;
		}
		elseif (!empty($userprofile->Email)) {
			$user_name = explode('@',  $userprofile->Email);
			$userprofile->username = $user_name[0];
		} 
    	else {
			$userprofile->username = $userprofile->ID;
		}
		$userprofile->Email=(!empty($userprofile->Email['0']->Value)?$userprofile->Email['0']->Value:"");
		if(isset($userprofile->ID)){
			$dbObj=$this->query($userprofile->ID);
			$id=(!empty($dbObj[0]['id_customer'])?$dbObj[0]['id_customer']:"");
			if($id<1){
			  if(!empty($userprofile->Email)){
			    $query3 = Db::getInstance()->ExecuteS('SELECT * FROM '.pSQL(_DB_PREFIX_.'customer').' as c WHERE c.email='." '$userprofile->Email' ".' LIMIT 0,1');
				$num=(!empty($query3['0']['id_customer'])?$query3['0']['id_customer']:"");
				if($num>=1) {
			     if($this->deletedUser($query3)){
                   $home = getHome();
				   $msg= "Authentication failed.";
				   popup_verify($msg,$home);
				   return;
               
             }
	       }
          }

				//new user. user not found in database. set all details
				if(Configuration::get('EMAIL_REQ')=="1" and empty($userprofile->Email)){
				storeInCookie($userprofile);
					popUpWindow();
					return;
				
					
				}elseif(Configuration::get('EMAIL_REQ')=="0" and empty($userprofile->Email)){
				$this->email_rand($userprofile);
				
					storeAndLogin($userprofile);
					return;
					
				}
				storeAndLogin($userprofile);
			}elseif($this->deletedUser($dbObj)){
		         	$home = getHome();
					$msg= "Authentication failed.";
					popup_verify($msg,$home);
					return;
				
			}
			if($this->verifiedUser($dbObj)){
				$this->loginUser($dbObj);
				return;
			}else{
				$home = getHome();
				$msg= "Please verify your email.";
				popup_verify($msg,$home);
				return;
			}
		}
	}

	function query($id){
		$slTbl=pSQL(_DB_PREFIX_).'sociallogin';
		$cusTbl=pSQL(_DB_PREFIX_.'customer');
		$id=pSQL($id);
		$q="SELECT * FROM `$slTbl` as sl INNER JOIN `$cusTbl` as c WHERE `sl`.`provider_id`='$id' and c.id_customer=sl.id_customer  LIMIT 0,1";
		$dbObj=Db::getInstance()->ExecuteS($q);
		return($dbObj);
	}

	function deletedUser($dbObj){
		$deleted=$dbObj['0']['deleted'];
		if($deleted==1){
			return true;
		}
		return false;
	}

	function verifiedUser($dbObj){
		$verified=$dbObj['0']['verified'];
		$rand=$dbObj['0']['rand'];
		if($verified==1 and $rand==''){
			return true;
		}
		return false;
	}

	function loginUser($dbObj){
		$arr=array();
		$arr['id']=$dbObj['0']['id_customer'];
		$arr['fname']=$dbObj['0']['firstname'];
		$arr['lname']=$dbObj['0']['lastname'];
		$arr['email']=$dbObj['0']['email'];
		$arr['pass']=$dbObj['0']['passwd'];        
		loginRedirect($arr);
	}

	function email_rand($userprofile){
     	switch( $userprofile->Provider) {
      		case 'twitter':
      		$userprofile->Email= $userprofile->ID.'@'.$userprofile->Provider.'.com';
      		break;
      		case 'linkedin':
        	$userprofile->Email = $userprofile->ID.'@'.$userprofile->Provider.'.com';
      		break;
      		default:
        	$Email_id = substr( $userprofile->ID,7);
        	$Email_id2 = str_replace("/","_",$Email_id);
        	$userprofile->Email = str_replace(".","_",$Email_id2).'@'. $userprofile->Provider .'.com';
        	break;
    	}
		
	}
}
?>
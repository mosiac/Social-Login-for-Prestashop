<?php
if ( !defined( '_PS_VERSION_' ) ){
	exit;
}
function extraFields($obj,$insert_id,$fname,$lname){
	$str="";
	if(isset($obj->Country->Code)){
		$ISO=$obj->Country->Code;
		$id=pSQL(getIdByCountryISO($ISO));
		$str.="id_country='$id',";
	}elseif($obj->Country->Name){
		$country=$obj->Country->Name;
		$id=pSQL(getIdByCountryName($country));
		$str.="id_country='$id',";
	}
	if(isset($obj->State)){
		$state=$obj->State;
		if(isset($id) and (is_numeric($id)) ){
			$iso=pSQL(getIsoByState($state,$id));
		}else{
			$iso=pSQL(getIsoByState($state));
		}		
		$str.="id_state='$iso',";
	}
	if(isset($obj->City)){
		$city=pSQL($obj->City);
		$str.="city='$city',";
	}
	if(isset($obj->Addresses['0']->PostalCode)){
		$zip=pSQL($obj->Addresses['0']->PostalCode);
		$str.="postcode='$zip',";
	}
	if(isset($obj->Addresses['0']->Address1)){
		$address=pSQL($obj->Addresses['0']->Address1);
		$str.="address1='$address',";
	}
	if(isset($obj->PhoneNumbers['0']->PhoneNumber)){
		$phone=pSQL($obj->PhoneNumbers['0']->PhoneNumber);
		$str.="phone='$phone',";
	}
	$date=date("y-m-d h:i:s");
	$str.="date_add='$date',date_upd='$date',";
	$tbl=_DB_PREFIX_."address";
	$fname=pSQL($fname);
	$lname=pSQL($lname);
	$q= "insert into $tbl set ".$str." id_customer='$insert_id', lastname='$fname',firstname='$lname' ";
	$q = Db::getInstance()->ExecuteS($q);
}
function extraFields2($insert_id,$fname,$lname){
	//by using cookie get all data.
	global $cookie;
	$str="";
	//starts here
	if(isset($cookie->SL_CCode)){
		$ISO=$cookie->SL_CCode;
		$id=pSQL(getIdByCountryISO($ISO));
		$str.="id_country='$id',";
	}elseif($cookie->SL_CName){
		$country=$cookie->SL_CName;
		$id=pSQL(getIdByCountryName($country));
		$str.="id_country='$id',";
	}
	if(isset($cookie->SL_State)){
		$state=$cookie->SL_State;
		if(isset($id) and (is_numeric($id)) ){
			$iso=pSQL(getIsoByState($state,$id));
		}else{
			$iso=pSQL(getIsoByState($state));
		}		
		$str.="id_state='$iso',";
	}
	if(isset($cookie->SL_City)){
		$city=pSQL($cookie->SL_City);
		$str.="city='$city',";
	}
	if(isset($cookie->SL_PCode)){
		$zip=pSQL($cookie->SL_PCode);
		$str.="postcode='$zip',";
	}
	if(isset($cookie->SL_Address)){
		$address=pSQL($cookie->SL_Address);
		$str.="address1='$address',";
	}
	if(isset($cookie->SL_Phone)){
		$phone=pSQL($cookie->SL_Phone);
		$str.="phone='$phone',";
	}
	$date=date("y-m-d h:i:s");
	$str.="date_add='$date',date_upd='$date',";
	$tbl=_DB_PREFIX_."address";
	$q= "insert into $tbl set ".$str." id_customer='$insert_id', firstname='$fname',lastname='$lname' ";
	$q = Db::getInstance()->ExecuteS($q);
	//ends here
}
function getIdByCountryISO($ISO){
	$tbl=_DB_PREFIX_."country";
	$field="iso_code";
	$ISO=pSQL(trim($ISO));
	$q="select * from $tbl where $field='$ISO'";
	$q = Db::getInstance()->ExecuteS($q);
	$iso="";
	if(isset($q[0]['iso'])){
		$iso=$q[0]['iso'];
	}
	return($iso);
}
function getIdByCountryName($country){
	$tbl=_DB_PREFIX_."country_lang";
	$country=pSQL(trim($country));
	$q="select * from $tbl where name='$country'";
	$q = Db::getInstance()->ExecuteS($q);
	$iso=$q[0]['id_country'];
	return($id);
}
function getIsoByState($state,$country=""){
	if(strlen(($country)>0)){
		$country=pSQL($country);
		$str="id_country='$country' and ";
	}else{
		$str="";
	}
	if(strlen(($state)>0)){
		$state=pSQL($state);
		$tbl=_DB_PREFIX_."state";
		$q="select * from $tbl where $str name='$id_state'";
		$q = Db::getInstance()->ExecuteS($q);
		$id=$q[0]['id_state'];
		return($id);
	}
}
?>
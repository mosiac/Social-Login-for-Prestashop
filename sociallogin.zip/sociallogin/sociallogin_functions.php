<?php
if ( !defined( '_PS_VERSION_' ) ){
	exit;
}
function already_logged_in(){
	global $cookie;
	if ($cookie->isLogged()){
		if ($back = Tools::getValue('back'))
			Tools::redirect($back);
		Tools::redirect('my-account.php');
	}else{
		$cookie->lr_login="false";
	}
}

function getSecret(){
	//return("http://prestashop.openidgeek.com");
	return(Configuration::get('API_SECRET'));
}
function dbQuery($query){
	return(Db::getInstance()->ExecuteS($query));
}
function outputHtml($string){
	echo $string;
}

function redirectURL(){
	$loc=Configuration::get('LoginRadius_redirect');
	if($loc=="backpage"){
		$loc=Tools::getValue('back');
	}elseif($loc=="profile"){
		$loc="my-account.php";
	}
	return($loc);
}

function loginRedirect($arr){
	global $cookie;
	$cookie->id_compare = $arr['id'];
	$cookie->id_customer = $arr['id'];
	$cookie->customer_lastname = $arr['lname'];
	$cookie->customer_firstname = $arr['fname'];
	$cookie->logged = 1;
	$cookie->passwd = $arr['pass'];
	$cookie->email = $arr['email'];
	$cookie->lr_login="true";
	Module::hookExec('authentication');
	$redirect=redirectURL();
	Tools::redirect($redirect);
}

function storeAndLogin($obj){
	$email=pSQL($obj->email);
	$provider_id=$obj->ID;
	$query3 = dbQuery('SELECT * FROM '.pSQL(_DB_PREFIX_.'customer').' as c WHERE c.email='." '$email' ".' LIMIT 0,1');
	$num=$query3['0']['id_customer'];
	//user email already exists in customer table
	if($num>=1){
		$insert_id=$num;
		//user id in social login too?
		$query2 = Db::getInstance()->ExecuteS('SELECT * FROM '.pSQL(_DB_PREFIX_.'sociallogin').' as sl WHERE sl.id_customer='." '$num' ".' LIMIT 0,1');
		$num=$query2['0']['id_customer'];
		if($num>=1){
			//update don't insert because user id is different ,have to update user id like facebook then twitter login. because already in database returns false;
			$tbl=pSQL(_DB_PREFIX_.'sociallogin');
			$query= "update $tbl set `provider_id`='$provider_id',`verified`='1',`rand`='' where `id_customer`='$num'";
			Db::getInstance()->ExecuteS($query);
		}else{
			$tbl=pSQL(_DB_PREFIX_.'sociallogin');
			$query= "insert into $tbl (`id_customer`,`provider_id`,`verified`,`rand`) values ('$insert_id','$provider_id','1','') ";
			Db::getInstance()->ExecuteS($query);
		}
		//login user
		$arr['id']=$num;
		$arr['lname']=$query3['0']['lastname'];
		$arr['fname']=$query3['0']['firstname'];
		$arr['pass']=$query3['0']['passwd'];
		$arr['email']=$query3['0']['email'];
		loginRedirect($arr);
		return;
	}
	//insert into customer and sociallogin table.
	$password = Tools::passwdGen();
	$pass=Tools::encrypt($password);
	$date_added=date("Y-m-d H:i:s",time());
	$date_updated=$date_added;
	$last_pass_gen=$date_added;
	$s_key = md5(uniqid(rand(), true));
	$fname=pSQL($obj->FirstName);
	$lname=pSQL($obj->LastName);
	$gender=pSQL($obj->Gender);
	$bday=pSQL($obj->BirthDate);
	$query= "insert into "._DB_PREFIX_."customer (`id_gender`,`id_default_group`,`firstname`,`lastname`,`email`,`passwd`,`last_passwd_gen`,`birthday`,`newsletter`,`optin`,`active`,`date_add`,`date_upd`,`secure_key` ) values ('$gender','1','$fname','$lname','$email','$pass','$last_pass_gen','$bday','0','0','1','$date_added','$date_updated','$s_key') ";
	Db::getInstance()->ExecuteS($query);
	$insert_id=mysql_insert_id();
	$tbl=pSQL(_DB_PREFIX_.'sociallogin');
	$query= "insert into $tbl (`id_customer`,`provider_id`,`verified`,`rand`) values ('$insert_id','$provider_id','1','') ";
	Db::getInstance()->ExecuteS($query);
	//extra data from here later to complete
	$tbl=pSQL(_DB_PREFIX_.'customer_group');
	$query= "insert into $tbl (`id_customer`,`id_group`) values ('$insert_id','1') ";
	Db::getInstance()->ExecuteS($query);
	include_once("socialogin_fields.php");
	extraFields($obj,$insert_id,$fname,$lname);
	$arr=array();
	$arr['id']=(string)$insert_id;
	$arr['lname']=$lname;
	$arr['fname']=$fname;
	$arr['pass']=$pass;
	$arr['email']=$email;
	loginRedirect($arr);
}

function storeInCookie($arr){
	//save details in cookie
	global $cookie;
	$cookie->ID=$arr->ID;
	$cookie->FirstName=$arr->FirstName;
	$cookie->LastName=$arr->LastName;
	$cookie->Gender=$arr->Gender;
	$cookie->BirthDate=$arr->BirthDate;
	if($arr->Country->Code){
		$cookie->SL_CCode=$arr->Country->Code;
	}elseif(isset($arr->Country->Name)){
		$cookie->SL_CName=$arr->Country->Name;
	}
	if(isset($arr->State)){
		$cookie->SL_State=$arr->State;
	}
	if(isset($arr->City)){
		$cookie->SL_City=$arr->City;
	}
	if(isset($arr->Addresses['0']->PostalCode)){
		$cookie->SL_PCode=$arr->Addresses['0']->PostalCode;
	}
	if(isset($arr->Addresses['0']->Address1)){
		$cookie->SL_Address=$arr->Addresses['0']->Address1;
	}
	if(isset($arr->PhoneNumbers['0']->PhoneNumber)){
		$cookie->SL_Phone=$arr->PhoneNumbers['0']->PhoneNumber;
	}
}

function getHome(){
	$http =(Configuration::get('PS_SSL_ENABLED'));
	if($http==0){
		$http ='http://';
	}else{
		$http ='https://';
	}
	$home=$http.Tools::getShopDomain().__PS_BASE_URI__;
	return($home);
}

function popUpWindow($msg=""){
	$home = getHome();
	if($msg==""){
		$msg="Please write email-";
	}
	?>
	<link rel="stylesheet" type="text/css" href="<?php echo $home; ?>modules/sociallogin/sociallogin_style.css" />
	<script language="javascript">
	function showHome(){
		document.location="<?php echo $home; ?>";
	}
	</script>
	<div id="popupouter">
	<div id="popupinner">
	<div id="textmatter"><?php echo $msg; ?></div>
	<form method="post" action="">
	<div><input type="text" name="SL_EMAIL" id="SL_EMAIL" class="inputtxt" /></div>
	<div>
	<?php
	global $cookie;
	$cookie->SL_hidden=microtime();
	?>
	<input type="hidden" name="hidden_val" value="<?php echo $cookie->SL_hidden; ?>" />
	<input type="submit" id="LoginRadiusRedSliderClick" name="LoginRadiusRedSliderClick" value="Submit" class="inputbutton">
	<input type="button" value="Cancel" class="inputbutton" onClick="showHome()" />
	</div>
	</form>
	<div id="textdivpopup">Powered by <a target="_blank" href="//www.loginradius.com"><span class="spanpopup">Login</span><span class="span1">Radius</span></a></div>
	</div>
	</div>
	<?php
}

function verifyEmail(){
	$tbl=pSQL(_DB_PREFIX_.'sociallogin');
	$pid=pSQL($_REQUEST['SL_PID']);
	$rand=pSQL($_REQUEST['SL_VERIFY_EMAIL']);
	$db = Db::getInstance()->ExecuteS("SELECT * FROM  ".pSQL(_DB_PREFIX_)."sociallogin  where rand='$rand' and provider_id='$pid'");
	$num=$db['0']['id_customer'];
	$home = getHome();
	?>
	<link rel="stylesheet" type="text/css" href="<?php echo $home; ?>modules/sociallogin/sociallogin_style.css" />
	<div id="popupouter">
	<div id="popupinner">
	<div id="textmatter">
	<?php
	if($num<1){
		echo "Email not found.";
		?>
		<div>
		<input type="button" value="Close it!" class="inputbutton" onclick="javascript:document.location='<?php echo $home; ?>';" />
		</div>
		</div>
		<div id="textdivpopup">Powered by <a target="_blank" href="//www.loginradius.com"><span class="spanpopup">Login</span><span class="span1">Radius</span></a></div>
		</div>
		</div>
		<?php
		return;
	}
	$q="update $tbl set verified='1' where rand='$rand' and provider_id='$pid'";
	Db::getInstance()->ExecuteS($q);
	$tbl=pSQL(_DB_PREFIX_.'customer');
	$q="update $tbl set active='1' where id_customer='$num'";
	Db::getInstance()->ExecuteS($q);
	echo "Email is verified.";
	?>
	<div>
	<input type="button" value="Close it!" class="inputbutton" onclick="javascript:document.location='<?php echo $home; ?>';" />
	</div>
	</div>
	<div id="textdivpopup">Powered by <a target="_blank" href="//www.loginradius.com"><span class="spanpopup">Login</span><span class="span1">Radius</span></a></div>
	</div>
	</div>
	<?php
}

function SL_email($to,$sub,$msg,$firstname,$lastname){
	if($_SERVER['HTTP_HOST']=="localhost"){
		echo "Email will work at online only.";
	}else{
	$home = getHome();
	?>
	<link rel="stylesheet" type="text/css" href="<?php echo $home; ?>modules/sociallogin/sociallogin_style.css" />
	<div id="popupouter">
	<div id="popupinner">
	<div id="textmatter">
	<?php
		echo "Email sent. Please check your email id to verify your account.";
		?>
		<div>
		<input type="button" value="Close it!" class="inputbutton" onclick="javascript:document.location='<?php echo $home; ?>';" />
		</div>
		</div>
		<div id="textdivpopup">Powered by <a target="_blank" href="//www.loginradius.com"><span class="spanpopup">Login</span><span class="span1">Radius</span></a></div>
		</div>
		</div>
		<?php
		$id_lang = (int)Configuration::get('PS_LANG_DEFAULT');
		$protocol_content = (Configuration::get('PS_SSL_ENABLED')) ? 'https://' : 'http://';
		$link=$protocol_content.Tools::getShopDomain().__PS_BASE_URI__;
		$vars = array(
				'{reply}' => $msg,
				'{link}' => $link
		);
		$headers = 'From: noreply@'.$link . "\r\n" .'X-Mailer: PHP/' . phpversion();
		mail($to,$sub,$msg,$from);
		//Mail::Send($id_lang, 'reply_msg', Mail::l($sub), $vars, $to);
	}
}
function SL_randomchar(){
	$char="";
	for($i=0;$i<20;$i++){
		$char.=rand(0,9);
	}
	return($char);
}

function SL_email_save($email){
	//if email id is validate?
	if (!Validate::isEmail($email)){
		popUpWindow("Please write correct email.");
		return;
	}
	$arr=array();
	global $cookie;
	//$arr['id']=$db['0']['id_customer'];
	if($_POST['hidden_val']!=$cookie->SL_hidden){
		echo "Cookie has been deleted, please try again.";
		return;	
	}
	$arr['fname']=pSQL($cookie->FirstName);
	$fname=$arr['fname'];
	$arr['lname']=pSQL($cookie->LastName);
	$lname=$arr['lname'];
	$arr['email']=$email;
	$password = Tools::passwdGen();
	$pass=Tools::encrypt($password);
	$date_added=date("Y-m-d H:i:s",time());
	$date_updated=$date_added;
	$last_pass_gen=$date_added;
	$s_key = md5(uniqid(rand(), true));
	$gender = pSQL ($cookie->Gender);
	$bday = pSQL($cookie->BirthDate);
	//if already in customer table then check if it's verified, if then...
	$email=pSQL($email);
	$query="select * from "._DB_PREFIX_."customer where email='$email'";
	$query = Db::getInstance()->ExecuteS($query);
	$num=$query['0']['id_customer'];
	if($num>=1){
		$query="select * from "._DB_PREFIX_."sociallogin where id_customer='$num'";
		$query = Db::getInstance()->ExecuteS($query);
		$num2=$query['0']['id_customer'];
		if($num2>=1){
			$rand=SL_randomchar();
			$id=$cookie->ID;
			$query="update "._DB_PREFIX_."sociallogin set `provider_id`='$id',`rand`='$rand',`verified`='0' where id_customer='$num'";
			Db::getInstance()->ExecuteS($query);
			$to=$email;
			$sub="Verify your email id. ";
			$protocol_content = (Configuration::get('PS_SSL_ENABLED')) ? 'https://' : 'http://';
			$provider_id=$id;
			$link=$protocol_content.Tools::getShopDomain().__PS_BASE_URI__."?SL_VERIFY_EMAIL=$rand&SL_PID=$provider_id";
			$msg="Please click here to verify your email id. Click $link";
			$sub="Verify your email id. ";
			SL_email($email,$sub,$msg,$fname,$lname);
			//include_once("socialogin_fields.php"); no need to fill extra fields..it's update query//extraFields($obj,$insert_id);
			return;
		}else{
			$rand=SL_randomchar();
			$id=$cookie->ID;
			$provider_id=$id;
			$query="insert into "._DB_PREFIX_."sociallogin set `provider_id`='$id',`rand`='$rand',`verified`='0',id_customer='$num'";
			Db::getInstance()->ExecuteS($query);
			$to=$email;
			$sub="Verify your email id. ";
			$protocol_content = (Configuration::get('PS_SSL_ENABLED')) ? 'https://' : 'http://';
			$link=$protocol_content.Tools::getShopDomain().__PS_BASE_URI__."?SL_VERIFY_EMAIL=$rand&SL_PID=$provider_id";
			$msg="Please click here to verify your email id. Click $link";
			$sub="Verify your email id. ";
			SL_email($email,$sub,$msg,$fname,$lname);
			return;
		}
	}
	$query= "insert into "._DB_PREFIX_."customer (`id_gender`,`id_default_group`,`firstname`,`lastname`,`email`,`passwd`,`last_passwd_gen`,`birthday`,`newsletter`,`optin`,`active`,`date_add`,`date_upd`,`secure_key` ) values ('$gender','1','$fname','$lname','$email','$pass','$last_pass_gen','$bday','0','1','0','$date_added','$date_updated','$s_key') ";
	Db::getInstance()->ExecuteS($query);
	$insert_id=mysql_insert_id();
	$provider_id=$cookie->ID;
	//provider id later
	$tbl=pSQL(_DB_PREFIX_.'sociallogin');
	$rand=SL_randomchar();
	$query= "insert into $tbl (`id_customer`,`provider_id`,`rand`,`verified`) values ('$insert_id','$provider_id','$rand','0') ";
	Db::getInstance()->ExecuteS($query);
	$to=$email;
	$sub="Verify your email id. ";
	$protocol_content = (Configuration::get('PS_SSL_ENABLED')) ? 'https://' : 'http://';
	$link=$protocol_content.Tools::getShopDomain().__PS_BASE_URI__."?SL_VERIFY_EMAIL=$rand&SL_PID=$provider_id";
	$msg="Please click here to verify your email id. Click $link";
	SL_email($to,$sub,$msg,$fname,$lname);
	$tbl=pSQL(_DB_PREFIX_.'customer_group');
	$query= "insert into $tbl (`id_customer`,`id_group`) values ('$insert_id','1') ";
	Db::getInstance()->ExecuteS($query);
	include_once("socialogin_fields.php");
	extraFields2($insert_id,$fname,$lname);
}
?>
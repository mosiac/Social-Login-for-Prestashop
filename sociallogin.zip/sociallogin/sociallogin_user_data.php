<?php
if ( !defined( '_PS_VERSION_' ) ){
	exit;
}

class LrUser{
	function __construct(){
		$this->getUser();
		if(isset($this->user->ID)){
			$dbObj=$this->query($this->user->ID);
			$id=$dbObj['0']['id_customer'];
			if($id<1){
				//new user. user not found in database. set all details
				$this->set_firstname();
				$this->lname_as_fname();
				if(isset($this->user->Provider) and ($this->user->Provider=="yahoo") ){
					$this->user->email=$this->user->Email['1']->Value;
					storeAndLogin($this->user);
					return;
				}elseif($this->user->Email['0']->Value){
					$this->user->email=$this->user->Email['0']->Value;
					storeAndLogin($this->user);
					return;
				}else{
					if($this->requiredEmail()){
						storeInCookie($this->user);
						popUpWindow();
						return;
					}else{
						$this->email_rand();
						storeAndLogin($this->user);
						return;
					}
				}
			}elseif($this->deletedUser($dbObj)){
			$home = getHome();
	?>
	<link rel="stylesheet" type="text/css" href="<?php echo $home; ?>modules/sociallogin/sociallogin_style.css" />
	<div id="popupouter">
	<div id="popupinner">
	<div id="textmatter">
	<?php
		echo "Authentication failed.";
		?>
		<div>
		<input type="button" value="Close it!" onclick="javascript:document.location='<?php echo $home; ?>';" class="inputbutton" />
		</div>
		</div>
		<div id="textdivpopup">Powered by <a target="_blank" href="//www.loginradius.com"><span class="spanpopup">Login</span><span class="span1">Radius</span></a></div>
		</div>
		</div>
		<?php
				return;
			}
			if($this->verifiedUser($dbObj)){
				$this->loginUser($dbObj);
				return;
			}else{
			$home = getHome();
	?>
	<link rel="stylesheet" type="text/css" href="<?php echo $home; ?>modules/sociallogin/sociallogin_style.css" />
	<div id="popupouter">
	<div id="popupinner">
	<div id="textmatter">
	<?php
		echo "Please verify your email.";
		?>
		<div>
		<input type="button" value="Close it!" onclick="javascript:document.location='<?php echo $home; ?>';" class="inputbutton" />
		</div>
		</div>
		<div id="textdivpopup">Powered by <a target="_blank" href="//www.loginradius.com"><span class="spanpopup">Login</span><span class="span1">Radius</span></a></div>
		</div>
		</div>
		<?php
				return;
			}
		}
	}

	function getUser(){
		include_once("LoginRadius.php");
		$secret = getSecret();
		$lr_obj=new LoginRadius();
		$this->user=$lr_obj->construct($secret);
	}

	function query($id){
		$slTbl=pSQL(_DB_PREFIX_).'sociallogin';
		$cusTbl=pSQL(_DB_PREFIX_.'customer');
		$id=pSQL($id);
		$q="SELECT * FROM `$slTbl` as sl INNER JOIN `$cusTbl` as c WHERE `sl`.`provider_id`='$id' and c.id_customer=sl.id_customer and active=1 LIMIT 0,1";
		$dbObj=dbQuery($q);
		return($dbObj);
	}

	function deletedUser($dbObj){
		$deleted=$dbObj['0']['deleted'];
		if($deleted==1){
			return true;
		}
		return false;
	}

	function verifiedUser($dbObj){
		$verified=$dbObj['0']['verified'];
		if($verified==1){
			return true;
		}
		return false;
	}

	function loginUser($dbObj){
		$arr=array();
		$arr['id']=$dbObj['0']['id_customer'];
		$arr['fname']=$dbObj['0']['firstname'];
		$arr['lname']=$dbObj['0']['lastname'];
		$arr['email']=$dbObj['0']['email'];
		$arr['pass']=$dbObj['0']['passwd'];
		loginRedirect($arr);
	}

	function notempty($var){
		if(empty($var)){
			return false;
		}
		return true;
	}

	function set_var($name,$values){
		if($this->notempty($this->user->$name)){
			return;
		}
		foreach($values as $value){
			if($this->notempty($this->user->$value)){
				$this->user->$name=$this->user->$value;
				break;
			}
		}
	}

	function name_as_email(){
		if(empty($this->user->Email['0']->Value)){
			return;
		}
		$email=$this->user->Email['0']->Value;
		$email=explode($email,"@");
		$beforeAtEmail=$email[0];
		$name=str_replace("_","",$beforeAtEmail);
		$this->user->FirstName=$name;
	}	

	function name_as_id(){
		$id=$this->user->ID;
		$num=strlen($id);
		$fname="";//remove all special characters.
		for($i=0;$i<$num;$i++){
			if(ctype_alnum($id[$i])){
				$fname.=$id[$i];
			}
		}
		$this->user->FirstName=$fname;
	}	

	function name_rand(){
		if($this->notempty($this->user->FirstName)){
			return;
		}
		$letters = range('a', 'z');
		for($i=0;$i<5;$i++){
			$this->user->FirstName.=$letters[rand(0,26)];
		}
	}

	function remove_special($field){
		$name=$field;
		$field= $this->user->$field;
		if(ctype_alpha($field)){
			return;
		}
		$len=strlen($field);
		$this->user->$name="";	
		for($i=0;$i<$len;$i++){
			if(ctype_alpha($field[$i])){
				$this->user->$name.=$field[$i];
			}
		}
	}

	function set_firstname(){
		if($this->notempty($this->user->FirstName)){
			return;
		}
		$arr=array("ProfileName","FullName","NickName");
		$this->set_var("FirstName",$arr);
		if($this->notempty($this->user->FirstName)){
			return;
		}
		$this->name_as_email();
		if($this->notempty($this->user->FirstName)){
			return;
		}
		$this->name_as_id();
		if($this->notempty($this->user->FirstName)){
			return;
		}
		$this->name_rand();
	}

	function lname_as_fname(){
		$field="FirstName";
		$this->remove_special($field);
		$field="LastName";
		$this->remove_special($field);
		$this->name_rand();
		if($this->notempty($this->user->LastName)){
			return;
		}
		$this->user->LastName=$this->user->FirstName;
	}

	function email_rand(){
		if($this->notempty($this->user->email)){
			return;
		}
		$id=$this->user->ID;
		$num=strlen($id);
		$beforeAt="";
		for($i=0;$i<$num;$i++){
			if(ctype_alnum($id[$i])){
				$beforeAt.=$id[$i];
			}
		}
		$letters = range('a', 'z');
		$char=$letters[rand(0,26)];
		if(!(empty($this->user->provider))){
			$provider=$this->user->provider;
		}else{
			$provider="example";
		}
		$email=$char.$beforeAt.'@'.$provider.'.com';
		$this->user->email=$email;
	}

	function requiredEmail(){
		$email_req = Configuration::get('EMAIL_REQ');
		if($email_req=="Y"){
			return true;
		}else{
			return false;
		}
	}
}
?>
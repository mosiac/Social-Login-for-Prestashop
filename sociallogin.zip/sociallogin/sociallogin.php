<?php
error_reporting(E_ALL);
if ( !defined( '_PS_VERSION_' ) ){
	exit;
}
/**
 *Created by loginradius.com ,email, date and other description will goes here....
**/
define("SL_NAME","sociallogin");
define("SL_VERSION","1.1");
define("SL_AUTHOR","LoginRadius");
define("SL_DESCRIPTION","Let your users log in and comment via their accounts with popular ID providers such as Facebook, Google, Twitter, Yahoo, Vkontakte and over 15 more!.");
define("SL_DISPLAY_NAME","Social Login");

class sociallogin extends Module{
	public function __construct(){
		$this->name = SL_NAME;
		$this->version = SL_VERSION;
		$this->author = SL_AUTHOR;
		$this->need_instance = 1;
		$this->module_key="3afa66f922e9df102449d92b308b4532";//don't change given by sir
		parent::__construct();
		$this->displayName = $this->l( SL_DISPLAY_NAME );
		$this->description = $this->l( SL_DESCRIPTION );
	}

	function httpcheck($ApiKey,$ApiSecrete){
		include_once(dirname(__FILE__)."/LoginRadius.php");
		$auth_obj=new LoginRadiusAuth();
		$iframe_details=$auth_obj->auth($ApiKey,$ApiSecrete);
		if(isset( $iframe_details->IsValid)){ 
			$this->IsAuth = true;
			return $iframe_details;
		}
	}
	public function hookLeftColumn( $params,$str="" ){
		include_once(dirname(__FILE__)."/sociallogin_functions.php");
		global $smarty;
		global $cookie;
		if ($cookie->isLogged()){
			return;
		}
		$API_KEY = Configuration::get('API_KEY');
		$protocol_content = (isset($useSSL) AND $useSSL AND Configuration::get('PS_SSL_ENABLED')) ? 'https://' : 'http://';
		$loc=$protocol_content.Tools::getShopDomain().__PS_BASE_URI__;
		if ($back = Tools::getValue('back')){
			$loc.="?back=$back";
		}else{
			$loc.="";
		}
		$API_SECRET = Configuration::get('API_SECRET');
		$obj =$this->httpcheck($API_KEY,$API_SECRET);
		$https=$obj->IsHttps;
		if($https==1){
			$http ='https://';
		}else{
			$http ='http://';
		}
		$iframeHeight = $obj->height;
		if (!$iframeHeight) {
			$iframeHeight = 50;
		}
		$iframeWidth = $obj->width;
		if (!$iframeWidth) {
			$iframeWidth = 169;
		}
		$loc=urlencode($loc);
		global $cookie;
		$cookie->lr_login="false";
		$margin_style="";
		if($str=="margin"){
			$margin_style='style="margin-left:8px;margin-bottom:8px;"';
		}
		$iframe='<iframe src="'.$http.'hub.loginradius.com/Control/PluginSlider2.aspx?apikey='.$API_KEY.'&callback='.$loc.'" width="'.$iframeWidth.'" height="'.$iframeHeight.'"
frameborder="0" scrolling="no" ></iframe>';
		$smarty->assign( 'margin_style', $margin_style );
		$smarty->assign( 'iframe', $iframe );
		return $this->display( __FILE__, 'loginradius.tpl' );
	}
	public function hookRightColumn( $params ){
		return $this->hookLeftColumn( $params );
	}
	public function hookCreateAccountTop( $params ){
		return $this->hookLeftColumn( $params,"margin" );
	}
	public function hookTop(){
		global $cookie;
		if ($cookie->isLogged()){
			return;
		}
		include_once(dirname(__FILE__)."/sociallogin_functions.php");
		if(isset($_REQUEST['token'])){
			include_once("sociallogin_user_data.php");
			$obj=new LrUser();
		}elseif(isset($_REQUEST['SL_VERIFY_EMAIL'])){
			verifyEmail();
		}elseif(isset($_REQUEST['hidden_val'])){
			global $cookie;
			if(isset($_POST['SL_EMAIL']) and ($_REQUEST['hidden_val']==$cookie->SL_hidden) ){
				if(isset($_POST['SL_EMAIL'])){
					SL_email_save($_POST['SL_EMAIL']);
				}
			}else{
				echo "Cookie problem. Are cookies disabled?";
			}
		}
	}
	public function install(){
		if(!parent::install()
		|| !$this->registerHook( 'leftColumn' )
		|| !$this->registerHook( 'createAccountTop' )
		|| !$this->registerHook( 'rightColumn' )
		|| !$this->registerHook( 'top' )
		)
		return false;
		$this->db_tbl();
	  	return true;
    }

	public function db_tbl(){
		$tbl=pSQL(_DB_PREFIX_.'sociallogin');
		$CREATE_TABLE=<<<SQLQUERY
		CREATE TABLE IF NOT EXISTS `$tbl` (
	  `id_customer` int(10) unsigned NOT NULL COMMENT 'foreign key of customers.',
	  `provider_id` varchar(100) NOT NULL,
	  `rand` varchar(20),
	  `verified` tinyint(1) NOT NULL
	)
SQLQUERY;
		Db::getInstance()->ExecuteS($CREATE_TABLE);
	}

	public function getContent(){
	  $html = '';
	  if(Tools::isSubmit('submitKeys'))  {
		if(Tools::getValue('API_SECRET')){
		   $val=Tools::getValue('LoginRadius_redirect');
		  if($val=="url"){
		  	$val=Tools::getValue('redirecturl');//redirecturl
		  }
		  Configuration::updateValue('LoginRadius_redirect',$val);
		  Configuration::updateValue('API_KEY', Tools::getValue('API_KEY'));
		  Configuration::updateValue('API_SECRET', Tools::getValue('API_SECRET'));
		  Configuration::updateValue('EMAIL_REQ', Tools::getValue('EMAIL_REQ'));
		  $html .= $this->displayConfirmation($this->l('Settings updated.'));
		}else{
		  $html .= $this->displayError($this->l('Keys are empty.'));
		}
	}
	$API_KEY = Configuration::get('API_KEY');
	$API_SECRET = Configuration::get('API_SECRET');
	$EMAIL_REQ = Configuration::get('EMAIL_REQ');
	if($EMAIL_REQ=="Y"){
	  	$check1='checked="checked"';
		$check2='';
	  }else{
	  	$check2='checked="checked"';
		$check1='';
	  }
	  $LoginRadius_redirect=Configuration::get('LoginRadius_redirect');
	  $checked[0]="";
	  $checked[1]="";
	  $checked[2]="";
	  $redirect="";
	  $jsVal=1;
	  if($LoginRadius_redirect=="backpage"){
	  	$checked[0]='checked="checked"';
	  }elseif($LoginRadius_redirect=="profile"){
	  	$checked[1]='checked="checked"';
	  }else{
	  	$checked[2]='checked="checked"';
		$redirect=$LoginRadius_redirect;
		$jsVal=0;
	  }
	  $html.='<h2>Social Login</h2><img src="../modules/sociallogin/sociallogin.png" style="float:left; margin-right:15px;"><b>'.$this->l('Thank you for installing the Social Login module!.').'</b><br /><br /><p>You can customize the settings for your module on this page, though you will have to choose your desired ID providers and get your unique <b>LoginRadius API Key & Secret</b> from <a href="http://www.loginradius.com" target="_blank">www.LoginRadius.com</a>. In order to make the login process secure, we require you to manage it from your LoginRadius account.</p>
	<p>LoginRadius is a North America based technology company that offers social login through popular hosts such as Facebook, Twitter, Google and over 15 more! For tech support or if you have any questions, please contact us at <b>hello@loginradius.com.</b></p>';
	  $html .= '<h2>'.$this->l('Module settings').'</h2>
 		<script language="javascript">
	  function hidetextbox(hide){
	  	if(hide==1){
			document.getElementById("redirectid").style.visibility ="hidden";
		}else{
			document.getElementById("redirectid").style.visibility ="visible";
		}
	  }
	   window.onload = function (){
		   hidetextbox('.$jsVal.');
		} 
	  </script>
	  <form action="'.$_SERVER['REQUEST_URI'].'" method="post">
		<fieldset>
		  <legend>'.$this->l('Settings').'</legend>
		  <div class="margin-form">
		  <label>'.$this->l('Login radius API key').'</label>
			<input type="text" size="40" name="API_KEY" value="'.$API_KEY.'" />
			</div>
		<div class="margin-form"><label>
			'.$this->l('Login radius secret Key').'</label>
			<input type="text" name="API_SECRET"  size="40" value="'.$API_SECRET.'" />
		  </div>
		   <div class="margin-form">	
			<h3>'.$this->l('Setting for Redirect after login').'</h3>
			 </div>
		   <div class="margin-form">
			<label>Redirect to the back page : </label> <input name="LoginRadius_redirect" value="backpage" type="radio" onclick="javascript:hidetextbox(1);" '.$checked[0].' />
			 </div>
		   <div class="margin-form">
			<label>Redirect to the profile: </label> <input name="LoginRadius_redirect" value="profile" type="radio" onclick="javascript:hidetextbox(1);" '.$checked[1].' />
			 </div>
		   <div class="margin-form">
			<label>Redirect to the following url:</label> <input name="LoginRadius_redirect" value="url" type="radio" onclick="javascript:hidetextbox(0);" '.$checked[2].' />
			 </div>
		   <div class="margin-form">
			<span id="redirectid"><label>Redirect to the following url:</label> <input type="text" name="redirecturl"  size="40" value="'.$redirect.'" /></span>
		 </div>
		  <div class="margin-form"><label>'.$this->l('Email Required').'</label> <b>Yes</b> <input type="radio" name="EMAIL_REQ" value="Y" '.$check1.' />
			<b>No</b> <input type="radio" name="EMAIL_REQ" value="N" '.$check2.' />
		  </div>
		  <div class="clear center"><p>&nbsp;</p>
			<input class="button" type="submit" name="submitKeys" value="'.$this->l('   Save   ').'" />
		  </div>
		</fieldset>
	  </form>';
	  $html .= '<fieldset class="space">
			<legend><img src="../img/admin/unknown.gif" alt="" class="middle" />'.$this->l('Module Help Links').'</legend>
			 <h3>'.$this->l('The above links help you for configration setting of the module.').'</h3>
			   <ol>
			 	<li><a href="https://www.loginradius.com/developers/Plugins/prestashop" target="_blank">'.$this->l('Documentation').'</a></li>
			 	<li><a href="http://prestashop.loginradius.com/" target="_blank">'.$this->l('Plugin webpage').'</a></li>
			 	<li><a href="https://www.loginradius.com/loginradius/aboutus" target="_blank">'.$this->l('About LoginRadius').'</a></li>
				<li><a href="http://blog.loginradius.com/" target="_blank">'.$this->l('LoginRadius Blog').'</a></li>
				<li><a href="https://www.loginradius.com/Plugins/" target="_blank">'.$this->l('Other LoginRadius plugins').'</a></li>
				<li><a href="https://www.loginradius.com/helpcenter/findanswer" target="_blank">'.$this->l('Tech Support').'</a></li>
			</ol>';
	  return $html;
	} 

	public function uninstall(){
		if ( !parent::uninstall() ){
			Db::getInstance()->Execute( 'DROP table `' . _DB_PREFIX_ . 'sociallogin`' );
		}
		Db::getInstance()->Execute( 'DROP table `' . _DB_PREFIX_ . 'sociallogin`' );
		parent::uninstall();
	}
}
?>